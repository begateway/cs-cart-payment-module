<?php
namespace beGateway\PaymentMethod;

class CreditCardHalva extends Base {
  public function getName() {
    return 'halva';
  }
}
?>
