<?php
namespace beGateway\PaymentMethod;

class CreditCard extends Base {
}
?>
